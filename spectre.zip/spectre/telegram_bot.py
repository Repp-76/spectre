"""
telegram_bot.py — SPECTRE Account Bot
======================================
Runs automatically inside `python run.py` alongside the two Flask
servers (as a background thread) — no separate process needed. It can
still be launched standalone too:

    python telegram_bot.py

It does NOT touch any Flask route, template, or the existing
categories/resources data — it only reads/writes the `accounts`,
`telegram_roles`, and `telegram_config` tables added for the login
system, via a plain sqlite3 connection to data/spectre.db.

Configuration (Bot Token + Super Admin Telegram ID) is entered in the
admin panel at /admin/accounts and stored in the database. Defaults
are pre-seeded on first run:
    - admin_id  = 7624612389   (the Super Admin's Telegram ID)
    - bot_token = (pre-filled with the token provided at setup —
                  change it via the admin panel anytime)

── Speed ─────────────────────────────────────────────────────────────────
Uses one persistent HTTPS connection (requests.Session with a small
retry policy) instead of opening a fresh TLS handshake per call, and
short timeouts on sendMessage separate from the long-polling timeout
on getUpdates — a `/start` reply should land in well under a second
once the update is received. Response speed is otherwise bounded by
Telegram's own servers and the phone's network connection, not by
this script.

── Roles ─────────────────────────────────────────────────────────────────
Super Admin (the configured admin_id) always has full access to every
command below. Below that, three delegated roles, ascending privilege:

    reseller : /create
    owner    : /create, /addreseller
    partner  : /create, /addreseller, /addowner

Partner is the second-highest role (just below Super Admin) and can
grant both owner and reseller. Owner can only grant reseller. Nobody
can grant a role at or above their own level.
Anyone with no role at all gets:
    "Anda tidak mempunyai sebarang akses, hubungi @Repp76 untuk
     membeli akses."

── Commands ─────────────────────────────────────────────────────────────
    /create username,password[,tempoh]
        Creates a normal login account (see WELCOME_MESSAGE for the
        full duration-format explanation).

    /addreseller telegram_id[,tempoh]
    /addpartner  telegram_id[,tempoh]
    /addowner    telegram_id[,tempoh]
        Grants a role to another Telegram account. No tempoh = the
        role is permanent. Same m/j/h/b/t duration format as accounts.
"""

import os
import sys
import time
import sqlite3
import logging
import traceback

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app import accounts as acc   # noqa: E402
from app import roles as roles_mod  # noqa: E402

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "spectre.db")
POLL_TIMEOUT = 25        # Telegram long-polling wait (getUpdates only)
SEND_TIMEOUT = (5, 10)   # (connect, read) — keeps replies snappy even on flaky mobile data
TICK_INTERVAL = 20  # seconds; keeps the countdown engine moving even if
                     # the bot is the only process currently running

# One persistent HTTPS connection, reused for every call, with a small
# automatic retry for transient network blips (very common on mobile
# data / Termux) — this is what removes multi-second delays caused by
# re-negotiating TLS on every single request.
_session = requests.Session()
_retry = Retry(total=2, backoff_factor=0.3, status_forcelist=[500, 502, 503, 504])
_adapter = HTTPAdapter(max_retries=_retry, pool_connections=4, pool_maxsize=4)
_session.mount("https://", _adapter)
_session.mount("http://", _adapter)

WELCOME_MESSAGE = (
    "👋 Selamat datang ke Bot Pengurusan Account Osint Spectre.\n\n"
    "Cara membuat account:\n\n"
    "Permanent:\n"
    "\"/create username,password\"\n\n"
    "Contoh:\n"
    "\"/create Repp76,76\"\n\n"
    "Account akan kekal sehingga dipadam oleh admin.\n\n"
    "Account dengan tempoh:\n"
    "\"/create username,password,tempoh\"\n\n"
    "Contoh:\n"
    "\"/create Repp76,76,7h\"\n\n"
    "Format tempoh yang disokong:\n\n"
    "- m = Minit\n"
    "- j = Jam\n"
    "- h = Hari\n"
    "- b = Bulan\n"
    "- t = Tahun\n\n"
    "Contoh:\n\n"
    "\"/create Ali,123,30m\"\n"
    "\"/create Ali,123,8j\"\n"
    "\"/create Ali,123,30h\"\n"
    "\"/create Ali,123,3b\"\n"
    "\"/create Ali,123,1t\"\n\n"
    "Jika tempoh dikosongkan:\n\n"
    "\"/create username,password\"\n\n"
    "Account akan menjadi Permanent."
)

ROLE_GRANT_USAGE = {
    "addreseller": "/addreseller telegram_id\n/addreseller telegram_id,7h",
    "addpartner":  "/addpartner telegram_id\n/addpartner telegram_id,7h",
    "addowner":    "/addowner telegram_id\n/addowner telegram_id,7h",
}

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(message)s"
)
log = logging.getLogger("spectre.bot")


def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    acc.ensure_schema(con)
    roles_mod.ensure_schema(con)
    acc.seed_default_config(con)
    return con


def get_bot_config():
    con = get_conn()
    try:
        token = acc.get_config(con, "bot_token", "")
        admin_id = acc.get_config(con, "admin_id", "")
        return (token or "").strip(), (admin_id or "").strip()
    finally:
        con.close()


def tg_call(token, method, http_timeout=SEND_TIMEOUT, **params):
    url = f"https://api.telegram.org/bot{token}/{method}"
    resp = _session.post(url, data=params, timeout=http_timeout)
    resp.raise_for_status()
    return resp.json()


def send_message(token, chat_id, text):
    try:
        tg_call(token, "sendMessage", chat_id=chat_id, text=text)
    except Exception:
        log.exception("Failed to send Telegram message")


def handle_create(token, chat_id, args_str):
    parts = [p.strip() for p in args_str.split(",")]
    if len(parts) < 2 or not parts[0] or not parts[1]:
        send_message(
            token, chat_id,
            "Format salah.\n\n"
            "/create username,password\n"
            "/create username,password,80h\n\n"
            "Unit tempoh: m=minit j=jam h=hari b=bulan t=tahun"
        )
        return

    username, password = parts[0], parts[1]
    duration = parts[2] if len(parts) > 2 and parts[2] else None

    con = get_conn()
    try:
        acc.create_account(con, username, password, duration)
    except acc.AccountError as e:
        send_message(token, chat_id, f"Gagal: {e}")
        return
    except acc.DurationError as e:
        send_message(token, chat_id, f"Format tempoh salah: {e}")
        return
    finally:
        con.close()

    label = f"Tempoh: {duration}" if duration else "Tempoh: Permanent"
    send_message(
        token, chat_id,
        f"Account dicipta.\n\nUsername: {username}\nPassword: {password}\n{label}"
    )
    log.info(f"Created account '{username}' ({'permanent' if not duration else duration})")


def handle_grant_role(token, chat_id, command, args_str, granter_role, granter_id):
    """command is one of 'addreseller' / 'addpartner' / 'addowner'."""
    target_role = roles_mod.GRANT_COMMANDS[command]

    if not roles_mod.can_grant(granter_role, target_role):
        send_message(
            token, chat_id,
            f"Anda tidak boleh memberikan role '{target_role}'. "
            f"Role anda tidak mencukupi untuk tindakan ini."
        )
        log.warning(f"Denied {command} from id={granter_id} (role={granter_role})")
        return

    parts = [p.strip() for p in args_str.split(",")]
    target_id = parts[0] if parts else ""
    duration = parts[1] if len(parts) > 1 and parts[1] else None

    if not target_id or not target_id.isdigit():
        send_message(
            token, chat_id,
            "Format salah.\n\n" + ROLE_GRANT_USAGE[command]
        )
        return

    con = get_conn()
    try:
        roles_mod.grant_role(con, target_id, target_role, duration, granted_by=granter_id)
    except roles_mod.DurationError as e:
        send_message(token, chat_id, f"Format tempoh salah: {e}")
        return
    finally:
        con.close()

    label = f"Tempoh: {duration}" if duration else "Tempoh: Permanent"
    send_message(
        token, chat_id,
        f"Role '{target_role}' diberikan kepada {target_id}.\n{label}"
    )
    log.info(f"Granted role '{target_role}' to id={target_id} by id={granter_id} ({'permanent' if not duration else duration})")


def process_update(token, admin_id, update):
    message = update.get("message") or update.get("edited_message")
    if not message:
        return
    chat = message.get("chat", {})
    chat_id = chat.get("id")
    from_id = str(message.get("from", {}).get("id", ""))
    text = (message.get("text") or "").strip()

    if not text.startswith("/"):
        return

    # /start and /help are informational only — no role required to view them.
    if text.startswith("/start") or text.startswith("/help"):
        send_message(token, chat_id, WELCOME_MESSAGE)
        return

    con = get_conn()
    try:
        role = roles_mod.effective_role(con, from_id, admin_id)
    finally:
        con.close()

    if role is None:
        send_message(token, chat_id, roles_mod.ACCESS_DENIED_MESSAGE)
        log.warning(f"Access denied for id={from_id} (no active role)")
        return

    allowed = roles_mod.allowed_commands_for(role)

    if text.startswith("/create"):
        if "create" not in allowed:
            send_message(token, chat_id, roles_mod.ACCESS_DENIED_MESSAGE)
            return
        handle_create(token, chat_id, text[len("/create"):].strip())

    elif text.startswith("/addreseller"):
        if "addreseller" not in allowed:
            send_message(token, chat_id, roles_mod.ACCESS_DENIED_MESSAGE)
            return
        handle_grant_role(token, chat_id, "addreseller", text[len("/addreseller"):].strip(), role, from_id)

    elif text.startswith("/addpartner"):
        if "addpartner" not in allowed:
            send_message(token, chat_id, roles_mod.ACCESS_DENIED_MESSAGE)
            return
        handle_grant_role(token, chat_id, "addpartner", text[len("/addpartner"):].strip(), role, from_id)

    elif text.startswith("/addowner"):
        if "addowner" not in allowed:
            send_message(token, chat_id, roles_mod.ACCESS_DENIED_MESSAGE)
            return
        handle_grant_role(token, chat_id, "addowner", text[len("/addowner"):].strip(), role, from_id)


def main():
    log.info("SPECTRE Telegram bot starting…")
    offset = None
    last_token = None
    last_tick = 0.0

    # Swallow any downtime since this process (or the main backend) last
    # ran, so account/role countdowns resume from exactly where they left off.
    con = get_conn()
    try:
        acc.resume_accounts(con)
        roles_mod.resume_roles(con)
    finally:
        con.close()

    while True:
        # Keep the countdown engine moving even if run.py isn't up right
        # now — accounts/roles still only lose time while *some* backend
        # process (this bot, or the main app) is alive.
        if time.time() - last_tick >= TICK_INTERVAL:
            con = get_conn()
            try:
                acc.tick_accounts(con)
                roles_mod.tick_roles(con)
            except Exception:
                log.exception("Tick error")
            finally:
                con.close()
            last_tick = time.time()

        token, admin_id = get_bot_config()

        if not token or token == "Tampal_bot_token":
            if last_token is not None:
                log.warning("Bot token not set — paste your real token via the admin panel.")
            last_token = None
            time.sleep(5)
            continue

        if token != last_token:
            log.info("Bot token loaded from admin panel configuration. Polling started.")
            last_token = token

        try:
            result = tg_call(
                token, "getUpdates",
                http_timeout=(5, POLL_TIMEOUT + 5),
                offset=offset, timeout=POLL_TIMEOUT
            )
            if not result.get("ok"):
                log.error(f"getUpdates error: {result}")
                time.sleep(5)
                continue

            for update in result.get("result", []):
                offset = update["update_id"] + 1
                try:
                    process_update(token, admin_id, update)
                except Exception:
                    log.error("Error processing update:\n" + traceback.format_exc())

        except requests.exceptions.RequestException as e:
            log.warning(f"Network error talking to Telegram: {e}. Retrying in 5s…")
            time.sleep(5)
        except Exception:
            log.error("Unexpected error in poll loop:\n" + traceback.format_exc())
            time.sleep(5)


if __name__ == "__main__":
    main()
