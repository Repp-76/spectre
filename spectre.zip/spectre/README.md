# SPECTRE OSINT Research Portal

Professional open-source intelligence navigation platform.
Cyberpunk black/red theme · Flask backend · SQLite · No external dependencies required.

---

## Project Structure

```
spectre/
├── run.py                      # Entry point
├── requirements.txt
├── app/
│   ├── __init__.py             # App factory, security headers
│   ├── database.py             # SQLite schema + seed data
│   ├── routes/
│   │   ├── main.py             # Public portal routes
│   │   ├── api.py              # JSON API (tree, search, export)
│   │   └── admin.py            # Admin CRUD panel
│   └── utils/
│       └── validators.py       # Input sanitisation
├── static/
│   ├── css/
│   │   ├── main.css            # Cyberpunk portal styles
│   │   └── admin.css           # Admin panel styles
│   └── js/
│       └── main.js             # Tree nav, search, UI logic
├── templates/
│   ├── base.html
│   ├── index.html              # Main portal page
│   └── admin/
│       ├── base_admin.html
│       ├── dashboard.html
│       ├── resources.html
│       ├── resource_form.html
│       ├── categories.html
│       ├── category_form.html
│       └── import.html
└── data/                       # Auto-created; holds spectre.db
    └── spectre.db
```

---

## Quick Start

### 1. Prerequisites
- Python 3.10+
- pip

### 2. Install dependencies

```bash
cd spectre
pip install -r requirements.txt
```

### 3. Run

```bash
python run.py
```

Open: **http://localhost:5000**
Admin: **http://localhost:5000/admin/**

The database is created automatically on first run with 150+ pre-loaded OSINT resources.

---

## API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/tree` | GET | Full nested category tree |
| `/api/categories/<id>` | GET | Category + its resources |
| `/api/search?q=<query>` | GET | Search categories & resources |
| `/api/export` | GET | Export all data as JSON |
| `/api/stats` | GET | Dashboard statistics |
| `/track/<id>` | POST | Log resource click (anonymous) |

---

## Admin Panel

Navigate to `/admin/` for:
- Add / Edit / Delete resources
- Add / Edit / Delete categories (unlimited nesting)
- Import JSON (file upload or paste)
- Export JSON (via `/api/export`)

---

## Security Notes

- All user input is sanitised via `bleach` before database writes
- Security headers applied to every response (CSP, X-Frame-Options, etc.)
- No authentication is included — add Flask-Login before exposing to a network
- Rate limiting can be re-enabled by uncommenting Flask-Limiter in `__init__.py`
- The platform is read-only by design — it only displays links, never fetches or scrapes

---

## Login System (Public Portal)

Everything below is **additive** — no existing route, template, style,
or the Admin panel's original behaviour was changed. All original
functionality still works exactly as before.

### 1. Start the servers
```bash
pip install -r requirements.txt
python run.py
```
This starts the same two servers as before (public :8980, admin :8089,
IP-restricted, unchanged).

### 2. Telegram bot is pre-configured
Your **Bot Token** and **Super Admin Telegram ID** (`7624612389`) are
already saved in the database — nothing to fill in. Change either one
anytime from the admin panel → **Account**.

### 3. Run the bot
No separate step needed — `python run.py` now starts the Telegram bot
automatically in the background alongside the two web servers. You'll
see it in the same terminal log. (You can still run
`python telegram_bot.py` standalone if you ever want the bot running
without the web servers.)

### 4. Create accounts via Telegram
```
/create Repp76,76            → permanent account
/create Ali,123,80h          → active for 80 hours
```
Duration units: `m`=minit `j`=jam `h`=hari `b`=bulan(~30d) `t`=tahun(~365d).
Units can be combined, e.g. `1t2b3h`.

### 5. Roles (who can create accounts)
Hierarchy, lowest to highest: **reseller < owner < partner < Super Admin**
(you). Each role's allowed commands:

| Role | Can use |
|---|---|
| reseller | `/create` |
| owner | `/create`, `/addreseller` |
| partner | `/create`, `/addreseller`, `/addowner` |
| Super Admin | everything, incl. `/addpartner` |

Nobody can grant a role at or above their own level — an owner can't
make another owner, a partner can't make another partner. Grant a role:
```
/addreseller telegram_id            → permanent
/addreseller telegram_id,7h         → 7 days
/addowner telegram_id,1t            → 1 year
/addpartner telegram_id             → Super Admin only
```
Anyone with no role gets: *"Anda tidak mempunyai sebarang akses,
hubungi @Repp76 untuk membeli akses."*

Role durations pause while the backend is offline too — same engine
as account durations (see below).

### 6. How login works
- The public portal (port 8980) now requires login for every page —
  `/login` and `/logout` are the only public routes.
- **Login once**: a 10‑year cookie carries the session; there is no
  server-side session store, so restarting Python / Termux /
  cloudflared / changing the tunnel URL never logs anyone out. Only
  account expiry does.
- **1 account = 1 device**: the first successful login binds the
  account to a device id generated in the browser (localStorage) plus
  a lightweight fingerprint. A second device attempting to log in
  with the same credentials is rejected until an admin clicks
  **Reset Device**. Note: this is the strongest binding achievable
  from a pure browser app — there's no bulletproof way to pin a
  "device" without a native client, so treat it as a strong deterrent
  rather than an unbreakable lock.
- **Buy Key** button on the login page opens Telegram (`@Repp76`)
  with the message pre-filled.

### 7. Managing accounts (Admin → Account)
Click **Info** on any row (or the username itself) to see everything
about that account: login dates, device ID/OS/browser/IP/timezone,
first & last login, last active time, and more. Also: search, sort,
**Tambah Tempoh** (add time, supports the same `m/j/h/b/t` tokens),
**Reset Device**, and **Remove**, with live stats that refresh
automatically.

## Legal

SPECTRE is an educational research tool.
All listed resources are publicly accessible open-source intelligence platforms.
This platform does not perform automated data collection, scraping, exploitation,
or any unauthorised access. Users are responsible for compliance with applicable laws.
