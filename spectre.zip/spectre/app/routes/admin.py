"""
app/routes/admin.py
-------------------
Admin panel routes: CRUD for categories and resources,
JSON import/export, and dashboard.

No authentication is implemented in this educational build —
add Flask-Login or HTTP Basic Auth before any public deployment.
"""

import json
from flask import (Blueprint, render_template, request, jsonify,
                   redirect, url_for, flash, current_app)
from ..database import get_db
from ..utils.validators import validate_resource, validate_category

admin_bp = Blueprint("admin", __name__)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _row(row):
    return dict(row) if row else None


def _all_categories_flat(db):
    """Return all categories as a flat list ordered for a <select> element."""
    return db.execute(
        "SELECT id, name, parent_id, sort_order FROM categories ORDER BY sort_order, name"
    ).fetchall()


# ── Dashboard ──────────────────────────────────────────────────────────────────

@admin_bp.route("/")
def dashboard():
    db = get_db()
    stats = {
        "total_resources":  db.execute("SELECT COUNT(*) FROM resources").fetchone()[0],
        "active_resources": db.execute("SELECT COUNT(*) FROM resources WHERE status='active'").fetchone()[0],
        "total_categories": db.execute("SELECT COUNT(*) FROM categories").fetchone()[0],
        "total_clicks":     db.execute("SELECT COUNT(*) FROM usage_log").fetchone()[0],
    }
    recent = db.execute("""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status,
               r.free, r.requires_account, r.added_at, c.name as cat_name
        FROM resources r JOIN categories c ON c.id = r.category_id
        ORDER BY r.added_at DESC LIMIT 10
    """).fetchall()
    return render_template("admin/dashboard.html", stats=stats,
                           recent=[_row(r) for r in recent])


# ── Resources ──────────────────────────────────────────────────────────────────

@admin_bp.route("/resources")
def list_resources():
    db   = get_db()
    page = max(1, int(request.args.get("page", 1)))
    per  = 25
    offset = (page - 1) * per
    total = db.execute("SELECT COUNT(*) FROM resources").fetchone()[0]
    rows  = db.execute("""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status, r.free,
               r.requires_account, r.added_at, c.name as cat_name
        FROM resources r JOIN categories c ON c.id = r.category_id
        ORDER BY r.added_at DESC LIMIT ? OFFSET ?
    """, (per, offset)).fetchall()
    return render_template("admin/resources.html",
                           resources=[_row(r) for r in rows],
                           page=page, total=total, per=per)


@admin_bp.route("/resources/new", methods=["GET", "POST"])
def new_resource():
    db = get_db()
    if request.method == "POST":
        ok, data, errors = validate_resource(request.form)
        if not ok:
            return render_template("admin/resource_form.html",
                                   categories=_all_categories_flat(db),
                                   errors=errors, form=request.form)
        db.execute("""
            INSERT INTO resources (name,description,url,category_id,tags,status,free,requires_account)
            VALUES (:name,:description,:url,:category_id,:tags,:status,:free,:requires_account)
        """, data)
        db.commit()
        current_app.logger.info(f"Admin: created resource '{data['name']}'")
        return redirect(url_for("admin.list_resources"))

    return render_template("admin/resource_form.html",
                           categories=_all_categories_flat(db),
                           errors=[], form={})


@admin_bp.route("/resources/<int:rid>/edit", methods=["GET", "POST"])
def edit_resource(rid):
    db  = get_db()
    row = db.execute("SELECT * FROM resources WHERE id=?", (rid,)).fetchone()
    if not row:
        return "Resource not found", 404

    if request.method == "POST":
        ok, data, errors = validate_resource(request.form)
        if not ok:
            return render_template("admin/resource_form.html",
                                   categories=_all_categories_flat(db),
                                   errors=errors, form=request.form, resource=_row(row))
        db.execute("""
            UPDATE resources
            SET name=:name, description=:description, url=:url, category_id=:category_id,
                tags=:tags, status=:status, free=:free, requires_account=:requires_account,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=:id
        """, {**data, "id": rid})
        db.commit()
        current_app.logger.info(f"Admin: updated resource id={rid}")
        return redirect(url_for("admin.list_resources"))

    resource = _row(row)
    resource["tags"] = json.loads(resource.get("tags") or "[]")
    return render_template("admin/resource_form.html",
                           categories=_all_categories_flat(db),
                           errors=[], form=resource, resource=resource)


@admin_bp.route("/resources/<int:rid>/delete", methods=["POST"])
def delete_resource(rid):
    db = get_db()
    row = db.execute("SELECT name FROM resources WHERE id=?", (rid,)).fetchone()
    if not row:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": "Not found"}), 404
        return redirect(url_for("admin.list_resources"))

    name = row["name"]
    db.execute("DELETE FROM resources WHERE id=?", (rid,))
    db.commit()
    current_app.logger.info(f"Admin: deleted resource \'{name}\' (id={rid})")

    # AJAX request from popup
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True, "deleted": name})

    return redirect(url_for("admin.list_resources"))


# ── Categories ─────────────────────────────────────────────────────────────────

@admin_bp.route("/categories")
def list_categories():
    db   = get_db()
    rows = db.execute("""
        SELECT c.id, c.name, c.slug, c.icon, c.sort_order,
               p.name as parent_name,
               COUNT(r.id) as resource_count
        FROM categories c
        LEFT JOIN categories p ON p.id = c.parent_id
        LEFT JOIN resources  r ON r.category_id = c.id
        GROUP BY c.id ORDER BY c.sort_order, c.name
    """).fetchall()
    return render_template("admin/categories.html",
                           categories=[_row(r) for r in rows])


@admin_bp.route("/categories/new", methods=["GET", "POST"])
def new_category():
    db = get_db()
    if request.method == "POST":
        ok, data, errors = validate_category(request.form)
        if not ok:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=errors, form=request.form)
        # Enforce slug uniqueness
        existing = db.execute("SELECT id FROM categories WHERE slug=?", (data["slug"],)).fetchone()
        if existing:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=["A category with this slug already exists."],
                                   form=request.form)
        db.execute("""
            INSERT INTO categories (name,slug,description,parent_id,icon,sort_order)
            VALUES (:name,:slug,:description,:parent_id,:icon,:sort_order)
        """, data)
        db.commit()
        current_app.logger.info(f"Admin: created category '{data['name']}'")
        return redirect(url_for("admin.list_categories"))

    return render_template("admin/category_form.html",
                           all_cats=_all_categories_flat(db),
                           errors=[], form={})


@admin_bp.route("/categories/<int:cid>/edit", methods=["GET", "POST"])
def edit_category(cid):
    db  = get_db()
    row = db.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()
    if not row:
        return "Category not found", 404

    if request.method == "POST":
        ok, data, errors = validate_category(request.form)
        if not ok:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=errors, form=request.form, category=_row(row))
        # Check slug uniqueness (exclude self)
        existing = db.execute(
            "SELECT id FROM categories WHERE slug=? AND id!=?", (data["slug"], cid)
        ).fetchone()
        if existing:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=["A category with this slug already exists."],
                                   form=request.form, category=_row(row))
        # Prevent self-parenting
        if data.get("parent_id") == cid:
            data["parent_id"] = None

        db.execute("""
            UPDATE categories
            SET name=:name, slug=:slug, description=:description,
                parent_id=:parent_id, icon=:icon, sort_order=:sort_order
            WHERE id=:id
        """, {**data, "id": cid})
        db.commit()
        current_app.logger.info(f"Admin: updated category id={cid}")
        return redirect(url_for("admin.list_categories"))

    return render_template("admin/category_form.html",
                           all_cats=_all_categories_flat(db),
                           errors=[], form=_row(row), category=_row(row))


@admin_bp.route("/categories/<int:cid>/delete", methods=["POST"])
def delete_category(cid):
    db = get_db()
    db.execute("DELETE FROM categories WHERE id=?", (cid,))
    db.commit()
    current_app.logger.info(f"Admin: deleted category id={cid}")
    return redirect(url_for("admin.list_categories"))


# ── JSON Import / Export ───────────────────────────────────────────────────────

@admin_bp.route("/import", methods=["GET", "POST"])
def import_json():
    db = get_db()
    if request.method == "POST":
        try:
            file = request.files.get("json_file")
            raw  = file.read() if file else request.form.get("json_data", "")
            payload = json.loads(raw)
        except Exception as e:
            return render_template("admin/import.html", error=f"Invalid JSON: {e}")

        imported_cats = 0
        imported_res  = 0
        errors        = []

        # Import categories first (respect parent relationships)
        for cat in payload.get("categories", []):
            try:
                ok, data, errs = validate_category(cat)
                if not ok:
                    errors.append(f"Category '{cat.get('name')}': {', '.join(errs)}")
                    continue
                existing = db.execute(
                    "SELECT id FROM categories WHERE slug=?", (data["slug"],)
                ).fetchone()
                if not existing:
                    db.execute("""
                        INSERT INTO categories (name,slug,description,parent_id,icon,sort_order)
                        VALUES (:name,:slug,:description,:parent_id,:icon,:sort_order)
                    """, data)
                    imported_cats += 1
            except Exception as e:
                errors.append(f"Category error: {e}")

        db.commit()

        # Import resources
        for res in payload.get("resources", []):
            try:
                ok, data, errs = validate_resource(res)
                if not ok:
                    errors.append(f"Resource '{res.get('name')}': {', '.join(errs)}")
                    continue
                db.execute("""
                    INSERT INTO resources (name,description,url,category_id,tags,status,free,requires_account)
                    VALUES (:name,:description,:url,:category_id,:tags,:status,:free,:requires_account)
                """, data)
                imported_res += 1
            except Exception as e:
                errors.append(f"Resource error: {e}")

        db.commit()
        current_app.logger.info(
            f"Admin import: {imported_cats} categories, {imported_res} resources."
        )
        return render_template("admin/import.html",
                               success=True,
                               imported_cats=imported_cats,
                               imported_res=imported_res,
                               errors=errors)

    return render_template("admin/import.html")
