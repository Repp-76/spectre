"""
app/routes/main.py
------------------
Main public-facing routes: index/portal, resource click logging.
"""

from flask import Blueprint, render_template, request, jsonify, abort
from ..database import get_db
import json

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """Render the main OSINT portal page."""
    db = get_db()

    # Dashboard stats
    total_resources  = db.execute("SELECT COUNT(*) FROM resources WHERE status='active'").fetchone()[0]
    total_categories = db.execute("SELECT COUNT(*) FROM categories").fetchone()[0]

    # Most used categories (by click count)
    top_categories = db.execute("""
        SELECT c.name, c.slug, c.icon, COUNT(ul.id) as hits
        FROM categories c
        LEFT JOIN resources r ON r.category_id = c.id
        LEFT JOIN usage_log ul ON ul.resource_id = r.id
        GROUP BY c.id
        ORDER BY hits DESC
        LIMIT 6
    """).fetchall()

    # Recently added resources
    recent_resources = db.execute("""
        SELECT r.name, r.url, r.description, r.added_at, c.name as cat_name
        FROM resources r
        JOIN categories c ON c.id = r.category_id
        WHERE r.status = 'active'
        ORDER BY r.added_at DESC
        LIMIT 8
    """).fetchall()

    return render_template(
        "index.html",
        total_resources=total_resources,
        total_categories=total_categories,
        top_categories=top_categories,
        recent_resources=recent_resources
    )


@main_bp.route("/track/<int:resource_id>", methods=["POST"])
def track_resource(resource_id):
    """
    Log an anonymous click event for a resource.
    Called by the frontend when a user clicks an external link.
    """
    db = get_db()
    resource = db.execute(
        "SELECT id FROM resources WHERE id=? AND status='active'", (resource_id,)
    ).fetchone()

    if not resource:
        return jsonify({"error": "Resource not found"}), 404

    db.execute("INSERT INTO usage_log (resource_id) VALUES (?)", (resource_id,))
    db.commit()
    return jsonify({"ok": True})
