"""
app/roles.py
------------
Telegram-side permission roles for the SPECTRE account bot.

Three roles, in ascending order of privilege:
    reseller < owner < partner

And above all of them, the hardcoded/configured Super Admin (the bot
owner) who always has full access to every command.

Permission table
-----------------
    reseller : /create                              (plain accounts only)
    owner    : /create, /addreseller
    partner  : /create, /addreseller, /addowner

Partner is the second-highest role (right below the Super Admin), so
it may grant both reseller and owner roles. Owner sits below partner,
so it may only grant reseller. Nobody may grant a role at or above
their own level — an owner can't make another owner, and a partner
can't make another partner. Only the Super Admin can grant "partner".

A role with no duration given is permanent. A role with a duration
(m/j/h/b/t, same format as accounts) counts down using the same
pausable engine as accounts.py — it only loses time while a backend
process is alive and ticking, so downtime never expires a role early.

Storage is fully independent of the accounts table (different table,
telegram_roles) — this module never touches accounts/categories/
resources/usage_log.
"""

import re
from datetime import datetime, timedelta

_DURATION_RE = re.compile(r"(\d+)\s*([mjhbt])", re.IGNORECASE)
_UNIT_SECONDS = {
    "m": 60,
    "j": 60 * 60,
    "h": 60 * 60 * 24,
    "b": 60 * 60 * 24 * 30,
    "t": 60 * 60 * 24 * 365,
}


class DurationError(ValueError):
    pass


def parse_duration(token):
    token = (token or "").strip().replace(" ", "").lower()
    matches = _DURATION_RE.findall(token)
    if not matches:
        raise DurationError(f"Invalid duration format: {token!r}")
    seconds = 0
    for n, unit in matches:
        seconds += int(n) * _UNIT_SECONDS[unit]
    return timedelta(seconds=seconds)


def _now():
    return datetime.utcnow()


def _iso(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else None


def _parse_iso(s):
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


# ── Roles / permissions ──────────────────────────────────────────────────────

ROLE_LEVELS = {"reseller": 1, "owner": 2, "partner": 3}

ROLE_COMMANDS = {
    "reseller": {"create"},
    "owner": {"create", "addreseller"},
    "partner": {"create", "addreseller", "addowner"},
}

SUPER_ADMIN_COMMANDS = {"create", "addreseller", "addpartner", "addowner"}

ACCESS_DENIED_MESSAGE = (
    "Anda tidak mempunyai sebarang akses, hubungi @Repp76 untuk membeli akses."
)

# Which role a given command grants, and which role level is required to
# be able to issue it.
GRANT_COMMANDS = {
    "addreseller": "reseller",
    "addpartner": "partner",
    "addowner": "owner",
}


def ensure_schema(con):
    con.executescript("""
        CREATE TABLE IF NOT EXISTS telegram_roles (
            telegram_id        TEXT PRIMARY KEY,
            role               TEXT NOT NULL,
            is_permanent       INTEGER DEFAULT 0,
            remaining_seconds  INTEGER,
            last_tick_at       TEXT,
            expires_at         TEXT,
            created_at         TEXT DEFAULT (datetime('now')),
            granted_by         TEXT
        );
    """)
    con.commit()


def get_role_row(con, telegram_id):
    return con.execute(
        "SELECT * FROM telegram_roles WHERE telegram_id=?", (str(telegram_id),)
    ).fetchone()


def is_role_expired(row):
    if row is None:
        return True
    if row["is_permanent"]:
        return False
    rem = row["remaining_seconds"]
    if rem is None:
        return False
    return rem <= 0


def role_remaining_label(row):
    if row["is_permanent"]:
        return "Permanent"
    rem = row["remaining_seconds"]
    if rem is None:
        return "Permanent"
    if rem <= 0:
        return "Expired"
    days = rem // 86400
    hours = (rem % 86400) // 3600
    minutes = (rem % 3600) // 60
    parts = []
    if days:
        parts.append(f"{days}h")
    if hours:
        parts.append(f"{hours}j")
    if minutes and not days:
        parts.append(f"{minutes}m")
    return " ".join(parts) if parts else "< 1m"


def grant_role(con, telegram_id, role, duration_token=None, granted_by=None):
    if role not in ROLE_LEVELS:
        raise ValueError(f"Unknown role: {role}")

    telegram_id = str(telegram_id).strip()
    now = _now()

    if duration_token:
        delta = parse_duration(duration_token)
        remaining_seconds = int(delta.total_seconds())
        expires_at = _iso(now + delta)
        last_tick_at = _iso(now)
        is_permanent = 0
    else:
        remaining_seconds = None
        expires_at = None
        last_tick_at = None
        is_permanent = 1

    con.execute("""
        INSERT INTO telegram_roles
            (telegram_id, role, is_permanent, remaining_seconds, last_tick_at, expires_at, granted_by)
        VALUES (?,?,?,?,?,?,?)
        ON CONFLICT(telegram_id) DO UPDATE SET
            role=excluded.role,
            is_permanent=excluded.is_permanent,
            remaining_seconds=excluded.remaining_seconds,
            last_tick_at=excluded.last_tick_at,
            expires_at=excluded.expires_at,
            granted_by=excluded.granted_by
    """, (telegram_id, role, is_permanent, remaining_seconds, last_tick_at, expires_at, str(granted_by or "")))
    con.commit()


def effective_role(con, telegram_id, super_admin_id):
    """Returns 'super_admin', a role name ('owner'/'partner'/'reseller'),
    or None if the user has no active access."""
    telegram_id = str(telegram_id).strip()
    if super_admin_id and telegram_id == str(super_admin_id).strip():
        return "super_admin"

    row = get_role_row(con, telegram_id)
    if row is None or is_role_expired(row):
        return None
    return row["role"]


def allowed_commands_for(role_name):
    if role_name == "super_admin":
        return SUPER_ADMIN_COMMANDS
    return ROLE_COMMANDS.get(role_name, set())


def can_grant(role_name, target_role):
    """Can a user with `role_name` grant `target_role` to someone else?"""
    if role_name == "super_admin":
        return True
    command = {"reseller": "addreseller", "partner": "addpartner", "owner": "addowner"}[target_role]
    return command in allowed_commands_for(role_name)


# ── Pausable countdown engine (mirrors app/accounts.py) ─────────────────────

def resume_roles(con):
    con.execute(
        "UPDATE telegram_roles SET last_tick_at=? "
        "WHERE is_permanent=0 AND remaining_seconds IS NOT NULL",
        (_iso(_now()),)
    )
    con.commit()


def tick_roles(con):
    now = _now()
    rows = con.execute("""
        SELECT telegram_id, remaining_seconds, last_tick_at FROM telegram_roles
        WHERE is_permanent=0 AND remaining_seconds IS NOT NULL
          AND remaining_seconds > 0 AND last_tick_at IS NOT NULL
    """).fetchall()

    for r in rows:
        last = _parse_iso(r["last_tick_at"])
        if last is None:
            continue
        elapsed = (now - last).total_seconds()
        if elapsed <= 0:
            continue
        new_remaining = max(0, r["remaining_seconds"] - int(elapsed))
        new_expires_est = _iso(now + timedelta(seconds=new_remaining))
        con.execute(
            "UPDATE telegram_roles SET remaining_seconds=?, last_tick_at=?, expires_at=? WHERE telegram_id=?",
            (new_remaining, _iso(now), new_expires_est, r["telegram_id"])
        )
    con.commit()
