# -*- coding: utf-8 -*-
# CodeShield Encrypted Python — Powered by Repp76
import base64, sys, os

# Pastikan direktori script ada dalam sys.path
try:
    _cs_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _cs_dir = os.getcwd()
for _cs_p in [_cs_dir, os.getcwd()]:
    if _cs_p not in sys.path:
        sys.path.insert(0, _cs_p)

_cs_parts = [
    "IiIiCnJ1bi5weSDigJQgU1BFQ1RSRSBPU0lOVCBQbGF0Zm9ybSBsYXVuY2hlcgo9PT09PT09PT09",
    "PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0KU3RhcnRzIFRXTyBzZXBhcmF0ZSBGbGFz",
    "ayBzZXJ2ZXJzIGluIHBhcmFsbGVsIHRocmVhZHM6CgogIFB1YmxpYyBwb3J0YWwgIOKGkiBodHRw",
    "Oi8vMC4wLjAuMDo4OTgwICAgKGFueW9uZSBjYW4gYWNjZXNzKQogIEFkbWluIHBhbmVsICAgIOKG",
    "kiBodHRwOi8vMC4wLjAuMDo4MDg5ICAgKElQLXJlc3RyaWN0ZWQsIHNlZSBBRE1JTl9BTExPV0VE",
    "X0lQUykKClVzYWdlOgogIHB5dGhvbiBydW4ucHkKCkVudmlyb25tZW50IHZhcmlhYmxlczoKICBT",
    "RUNSRVRfS0VZICAgICAgICAg4oCUIEZsYXNrIHNlY3JldCBrZXkgKGNoYW5nZSBpbiBwcm9kdWN0",
    "aW9uISkKICBBRE1JTl9BTExPV0VEX0lQUyAg4oCUIENvbW1hLXNlcGFyYXRlZCBJUHMgYWxsb3dl",
    "ZCB0byBhY2Nlc3MgYWRtaW4KICAgICAgICAgICAgICAgICAgICAgICBlLmcuICIxOTIuMTY4LjEu",
    "NSwxMC4wLjAuMyIKICAgICAgICAgICAgICAgICAgICAgICBMb2NhbGhvc3QgKDEyNy4wLjAuMSAv",
    "IDo6MSkgaXMgYWx3YXlzIGFsbG93ZWQuCiIiIgoKaW1wb3J0IHRocmVhZGluZwppbXBvcnQgbG9n",
    "Z2luZwpmcm9tIGFwcCBpbXBvcnQgY3JlYXRlX3B1YmxpY19hcHAsIGNyZWF0ZV9hZG1pbl9hcHAK",
    "ClBVQkxJQ19IT1NUID0gIjAuMC4wLjAiClBVQkxJQ19QT1JUID0gODk4MAoKQURNSU5fSE9TVCAg",
    "PSAiMC4wLjAuMCIKQURNSU5fUE9SVCAgPSA4MDg5CgoKZGVmIHJ1bl9wdWJsaWMoKToKICAgIGFw",
    "cCA9IGNyZWF0ZV9wdWJsaWNfYXBwKCkKICAgIGFwcC5sb2dnZXIuaW5mbyhmIlB1YmxpYyBwb3J0",
    "YWwgIOKGkiBodHRwOi8ve1BVQkxJQ19IT1NUfTp7UFVCTElDX1BPUlR9IikKICAgICMgdXNlX3Jl",
    "bG9hZGVyPUZhbHNlIGlzIHJlcXVpcmVkIHdoZW4gcnVubmluZyBpbiB0aHJlYWRzCiAgICBhcHAu",
    "cnVuKGhvc3Q9UFVCTElDX0hPU1QsIHBvcnQ9UFVCTElDX1BPUlQsCiAgICAgICAgICAgIGRlYnVn",
    "PUZhbHNlLCB1c2VfcmVsb2FkZXI9RmFsc2UsIHRocmVhZGVkPVRydWUpCgoKZGVmIHJ1bl9hZG1p",
    "bigpOgogICAgYXBwID0gY3JlYXRlX2FkbWluX2FwcCgpCiAgICBhcHAubG9nZ2VyLmluZm8oZiJB",
    "ZG1pbiBwYW5lbCAgICDihpIgaHR0cDovL3tBRE1JTl9IT1NUfTp7QURNSU5fUE9SVH0iKQogICAg",
    "YXBwLnJ1bihob3N0PUFETUlOX0hPU1QsIHBvcnQ9QURNSU5fUE9SVCwKICAgICAgICAgICAgZGVi",
    "dWc9RmFsc2UsIHVzZV9yZWxvYWRlcj1GYWxzZSwgdGhyZWFkZWQ9VHJ1ZSkKCgppZiBfX25hbWVf",
    "XyA9PSAiX19tYWluX18iOgogICAgbG9nZ2luZy5iYXNpY0NvbmZpZygKICAgICAgICBsZXZlbD1s",
    "b2dnaW5nLklORk8sCiAgICAgICAgZm9ybWF0PSJbJShhc2N0aW1lKXNdICUobGV2ZWxuYW1lKXMg",
    "JShtZXNzYWdlKXMiCiAgICApCgogICAgcHJpbnQoIiIiCiAg4pWU4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ",
    "4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ",
    "4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ",
    "4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWXCiAg4pWRICAgICAgICAgIFMgUCBFIEMg",
    "VCBSIEUgICBPIFMgSSBOIFQgICBQIE8gUiBUIEEgTCAgICDilZEKICDilaDilZDilZDilZDilZDi",
    "lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDi",
    "lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDi",
    "lZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilaMKICDilZEgIFB1YmxpYyBwb3J0",
    "YWwgIOKGkiAgaHR0cDovLzAuMC4wLjA6ODk4MCAgICAgICAgICAgICAg4pWRCiAg4pWRICBBZG1p",
    "biBwYW5lbCAgICDihpIgIGh0dHA6Ly8wLjAuMC4wOjgwODkgICAgICAgICAgICAgIOKVkQogIOKV",
    "kSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKV",
    "kQogIOKVkSAgQWRtaW4gaXMgSVAtcmVzdHJpY3RlZCAobG9jYWxob3N0IGJ5IGRlZmF1bHQpLiAg",
    "ICAgIOKVkQogIOKVkSAgU2V0IEFETUlOX0FMTE9XRURfSVBTIGVudiB0byBhZGQgbW9yZSBJUHMu",
    "ICAgICAgICAgIOKVkQogIOKVmuKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKV",
    "kOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKV",
    "kOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKV",
    "kOKVkOKVkOKVkOKVnQogICAgIiIiKQoKICAgIHRfcHVibGljID0gdGhyZWFkaW5nLlRocmVhZCh0",
    "YXJnZXQ9cnVuX3B1YmxpYywgZGFlbW9uPVRydWUsIG5hbWU9InB1YmxpYyIpCiAgICB0X2FkbWlu",
    "ICA9IHRocmVhZGluZy5UaHJlYWQodGFyZ2V0PXJ1bl9hZG1pbiwgIGRhZW1vbj1UcnVlLCBuYW1l",
    "PSJhZG1pbiIpCgogICAgdF9wdWJsaWMuc3RhcnQoKQogICAgdF9hZG1pbi5zdGFydCgpCgogICAg",
    "IyBLZWVwIG1haW4gdGhyZWFkIGFsaXZlCiAgICB0cnk6CiAgICAgICAgdF9wdWJsaWMuam9pbigp",
    "CiAgICAgICAgdF9hZG1pbi5qb2luKCkKICAgIGV4Y2VwdCBLZXlib2FyZEludGVycnVwdDoKICAg",
    "ICAgICBwcmludCgiXG5bU1BFQ1RSRV0gU2h1dHRpbmcgZG93bi4iKQo="
]
_cs_b64 = "".join(_cs_parts)
_cs_code = base64.b64decode(_cs_b64).decode("utf-8")

# Bina globals dict lengkap — sama seperti Python jalankan file biasa
try:
    _cs_file = os.path.abspath(__file__)
except NameError:
    _cs_file = os.path.join(os.getcwd(), "script.py")

_cs_globals = {
    "__name__": "__main__",
    "__file__": _cs_file,
    "__doc__": None,
    "__package__": None,
    "__spec__": None,
    "__loader__": None,
    "__builtins__": __builtins__,
}

exec(compile(_cs_code, _cs_file, "exec"), _cs_globals)
